
const promoBanner = document.createElement('div');
promoBanner.innerHTML = '<div style="position:fixed;top:0;left:0;width:100%;background:#fffae6;padding:10px;z-index:9999;text-align:center;font-size:16px;border-bottom:2px solid #ffc107;">✨ SmartShopper: Don’t miss exclusive deals for you! ✨</div>';
document.body.appendChild(promoBanner);
