// content.js
const searchTriggers = ["search", "q", "query", "keyword", "k"];

function extractSearchQuery() {
  for (const name of searchTriggers) {
    const el = document.querySelector(`input[name="${name}"]`);
    if (el && el.value && el.value.length > 3) return el.value;
  }
  // Try to get from URL for some sites if not a search input
  const urlParams = new URLSearchParams(window.location.search);
  for (const name of searchTriggers) {
    if (urlParams.has(name) && urlParams.get(name).length > 3) {
      return urlParams.get(name);
    }
  }
  return null;
}

// --- Placeholder for your Render.com Backend URL ---
// You MUST replace this with your actual deployed Render.com backend URL
const RENDER_BACKEND_URL = "https://your-render-backend.onrender.com/cluster-data"; 

// Function to send data to your Render.com backend
async function sendDataToBackend(data) {
    try {
        const response = await fetch(RENDER_BACKEND_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) {
            console.error(`Backend API error: ${response.status} ${response.statusText}`);
        } else {
            const result = await response.json();
            console.log("Data sent to backend successfully:", result);
            // You might want to store or display the backend's response
        }
    } catch (error) {
        console.error("Error sending data to backend:", error);
    }
}

// Listen for a message from popup.js to initiate the analysis
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === "start_deal_analysis") {
        console.log("Content script: Received start_deal_analysis message from popup.");
        
        const query = extractSearchQuery();
        const currentUrl = window.location.href; // Get current URL for context

        if (query) {
            // Send the query to the background script for Gemini analysis
            chrome.runtime.sendMessage({
                type: "analyze_deals",
                query: query,
                sourceUrl: currentUrl // Provide the URL for context
            });
            console.log("Content script: Sent analyze_deals message to background with query:", query);

            // Send data to your Render.com backend for clustering
            sendDataToBackend({
                userId: "user_id_placeholder", // Replace with actual user ID if available (e.g., from Chrome Identity API or your auth system)
                searchQuery: query,
                timestamp: new Date().toISOString(),
                urlVisited: currentUrl
                // Add more user behavior data as needed for clustering
            });

        } else {
            // If no query is found, still send a message, but indicate no specific query
            chrome.runtime.sendMessage({
                type: "analyze_deals",
                query: "general online deals", // Fallback query
                sourceUrl: currentUrl
            });
            console.log("Content script: No specific query found, sending general analysis request.");
        }
        
        sendResponse({ success: true }); // Acknowledge receipt
    }
});