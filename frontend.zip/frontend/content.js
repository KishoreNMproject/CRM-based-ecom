chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "GET_PRODUCT_CONTEXT") {
    let title = "";
    let description = "";

    const hostname = window.location.hostname;

    if (hostname.includes("amazon")) {
      title = document.getElementById("productTitle")?.innerText || "";
      description = document.getElementById("feature-bullets")?.innerText || "";
    } else if (hostname.includes("flipkart")) {
      title = document.querySelector("span.B_NuCI")?.innerText || "";
      description = document.querySelector("div._1mXcCf")?.innerText || "";
    } else if (hostname.includes("ebay")) {
      title = document.querySelector("h1[itemprop='name']")?.innerText || "";
      description = document.querySelector("div.item-desc")?.innerText || "";
    } else if (hostname.includes("newegg")) {
      title = document.querySelector("h1.product-title")?.innerText || "";
      description = document.querySelector(".product-bullets")?.innerText || "";
    } else if (hostname.includes("jawa")) {
      title = document.querySelector("h1")?.innerText || document.title;
      description = document.querySelector("meta[name='description']")?.content || "";
    }

    sendResponse({ title, description });
  }

  return true; // Keep message channel open
});
